<?php
define('DEBUG', true);
define('DEFAULT_CONTROLLER', 'Home');
define('DEFAULT_LAYOUT', 'defaultLayout');
define('PROOT', '/'); //Later we will set this to '/' when working for live server
define('SITE_TITLE', 'Email Campaign');

define('DB_NAME', 'EmailCampaign');
define('DB_USER', 'manish');
define('DB_PASSWORD', 'M@ths7575');
define('DB_HOST', '127.0.0.1');

define('CURRENT_USER_SESSION_NAME', 'lkhdndjdeoeookddjj');
define('REMEMBER_ME_COOKIE_NAME', 'HJJDHDOIWOEIPWEOioei');
define('REMEMBER_ME_COOKIE_EXPIRY', 304800);

define('GOOGLE_CLIENT_ID', '1090694937783-84ii1kiifhapjrfn4ski3s6q4dn97ds3.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '-HXWJ0aS0q-CDRD88_08hnjI');
define('GOOGLE_REDIRECT_URL', 'http://ec2-3-6-171-185.ap-south-1.compute.amazonaws.com/user/login');

define('SES_HOST', 'email-smtp.ap-south-1.amazonaws.com');
define('SESUSERNAME', 'AKIA6B5RCAR6CRP7TQCI');
define('SESPPASSWORD', 'BEe7hlrvq1pl9NaDImsjZsp2jDbz31aIOjN/etDa/KKws');
define('SESSECURE', 'tls');
define('SESPORT', 587);

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTPUSERNAME', 'sharma.manish7575@gmail.com');
define('SMTPPASSWORD', 'M@ths7575');
define('SMTPSECURE', 'ssl');
define('SMTPPORT', 465);
