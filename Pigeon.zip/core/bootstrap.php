<?php
require_once(ROOT . DS . 'config' . DS . 'config.php');
require_once(ROOT . DS . 'app' . DS . 'Library' . DS . 'Helpers' . DS . 'functions.php');
require_once ROOT . DS . 'api/google-api-php-client/Google_Client.php';
require_once ROOT . DS . 'api/google-api-php-client/contrib/Google_Oauth2Service.php';
require(ROOT . DS . 'core' . DS . 'autoload.php');
